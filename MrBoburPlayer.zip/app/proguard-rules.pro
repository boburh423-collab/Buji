# Debug build uchun maxsus qoida kerak emas.
