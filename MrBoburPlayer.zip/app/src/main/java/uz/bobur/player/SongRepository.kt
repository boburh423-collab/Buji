package uz.bobur.player

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore

/** Telefondagi musiqalarni MediaStore orqali topadi (30 soniyadan qisqalari olinmaydi). */
object SongRepository {

    private const val MIN_DURATION_MS = 30_000L

    fun load(context: Context): List<Song> {
        val collection = if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
        )
        val selection =
            "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= ?"
        val args = arrayOf(MIN_DURATION_MS.toString())
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        val result = ArrayList<Song>()
        context.contentResolver.query(collection, projection, selection, args, sort)?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val title = c.getString(titleCol)?.takeIf { it.isNotBlank() } ?: "Nomsiz qo'shiq"
                val artistRaw = c.getString(artistCol)
                val artist = if (artistRaw.isNullOrBlank() || artistRaw == "<unknown>") {
                    "Noma'lum ijrochi"
                } else artistRaw
                val albumRaw = c.getString(albumCol)
                val album = if (albumRaw.isNullOrBlank() || albumRaw == "<unknown>") "" else albumRaw
                val duration = c.getLong(durCol)
                result.add(
                    Song(
                        id = id,
                        title = title,
                        artist = artist,
                        album = album,
                        durationMs = duration,
                        uri = ContentUris.withAppendedId(collection, id),
                    )
                )
            }
        }
        return result
    }
}
