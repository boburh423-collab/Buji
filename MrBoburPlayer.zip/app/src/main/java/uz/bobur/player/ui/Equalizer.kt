package uz.bobur.player.ui

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.bobur.player.AudioFx
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun EqualizerScreen(onClose: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        AppBackground(overlayAlpha = 0.60f)

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(top = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconBtn(Ic.Chevron, onClose, iconSize = 26.dp)
                Text(
                    "Ekvalayzer",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
                Switch(
                    checked = AudioFx.enabled,
                    onCheckedChange = { AudioFx.setEnabled(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Pink,
                        uncheckedThumbColor = Color.White.copy(alpha = 0.8f),
                        uncheckedTrackColor = Color.White.copy(alpha = 0.2f),
                    ),
                    modifier = Modifier.padding(end = 4.dp)
                )
            }
            Text(
                if (AudioFx.enabled) "Yoqilgan" else "O'chirilgan",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 12.sp,
                textAlign = TextAlign.End,
                modifier = Modifier.fillMaxWidth().padding(end = 10.dp)
            )

            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(top = 10.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Chastota polosalari
                Column(
                    Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(24.dp), 0.11f)
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Text("Chastota polosalari", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    if (!AudioFx.available || AudioFx.freqs.isEmpty()) {
                        Text(
                            "Ekvalayzer hozircha tayyor emas yoki bu qurilmada qo'llab-quvvatlanmaydi.",
                            color = Color.White.copy(alpha = 0.65f),
                            fontSize = 13.sp
                        )
                    } else {
                        for (i in AudioFx.freqs.indices) {
                            if (i >= AudioFx.levels.size) break
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    freqLabel(AudioFx.freqs[i]),
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 12.sp,
                                    modifier = Modifier.width(64.dp)
                                )
                                Slider(
                                    value = AudioFx.levels[i].toFloat(),
                                    onValueChange = { AudioFx.setBand(i, it.roundToInt()) },
                                    valueRange = AudioFx.minLevel.toFloat()..AudioFx.maxLevel.toFloat(),
                                    enabled = AudioFx.enabled,
                                    colors = appSliderColors(),
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    String.format(Locale.US, "%+.0f dB", AudioFx.levels[i] / 100f),
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.End,
                                    modifier = Modifier.width(56.dp)
                                )
                            }
                        }
                    }
                }

                // Bas va 3D
                Column(
                    Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(24.dp), 0.11f)
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    EffectSlider(
                        title = "Bas (BassBoost)",
                        value = AudioFx.bass,
                        supported = AudioFx.bassSupported,
                        onChange = { AudioFx.setBass(it) }
                    )
                    Spacer(Modifier.height(10.dp))
                    EffectSlider(
                        title = "3D effekt (Virtualizer)",
                        value = AudioFx.virt,
                        supported = AudioFx.virtSupported,
                        onChange = { AudioFx.setVirt(it) }
                    )
                }

                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    GradientButton("Tiklash", { AudioFx.reset() })
                }
            }
        }
    }
}

@Composable
private fun EffectSlider(title: String, value: Int, supported: Boolean, onChange: (Int) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(
                if (supported) "${value / 10}%" else "Mavjud emas",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 13.sp
            )
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = 0f..1000f,
            enabled = AudioFx.enabled && supported,
            colors = appSliderColors()
        )
    }
}

private fun freqLabel(hz: Int): String {
    if (hz < 1000) return "$hz Hz"
    val k = hz / 1000f
    return if (k == k.toInt().toFloat()) "${k.toInt()} kHz" else String.format(Locale.US, "%.1f kHz", k)
}
