package uz.bobur.player.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import uz.bobur.player.MusicViewModel

@Composable
fun AppRoot(vm: MusicViewModel) {
    val context = LocalContext.current

    val audioPerm = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    fun hasPerm() =
        ContextCompat.checkSelfPermission(context, audioPerm) == PackageManager.PERMISSION_GRANTED

    var granted by remember { mutableStateOf(hasPerm()) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        granted = hasPerm()
        if (granted) vm.loadSongs()
    }

    var showSplash by rememberSaveable { mutableStateOf(true) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var showEq by rememberSaveable { mutableStateOf(false) }

    // Ilovaga qaytganda ruxsatni va ro'yxatni yangilaydi (sozlamalardan qaytganda ham).
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                granted = hasPerm()
                if (granted) vm.loadSongs()
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    // Splash tugagach ruxsat so'raladi.
    LaunchedEffect(showSplash) {
        if (!showSplash && !granted) {
            val perms = buildList {
                add(audioPerm)
                if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            }
            launcher.launch(perms.toTypedArray())
        }
    }

    BackHandler(enabled = showEq) { showEq = false }
    BackHandler(enabled = showPlayer && !showEq) { showPlayer = false }

    Box(Modifier.fillMaxSize()) {
        LibraryScreen(
            vm = vm,
            granted = granted,
            onRequestPermission = {
                val perms = buildList {
                    add(audioPerm)
                    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
                }
                launcher.launch(perms.toTypedArray())
            },
            onOpenSettings = {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(Uri.fromParts("package", context.packageName, null))
                )
            },
            onOpenPlayer = { showPlayer = true }
        )

        // Pleyer: mini-pleyerga bosilganda pastdan sirpanib chiqadi
        AnimatedVisibility(
            visible = showPlayer,
            enter = slideInVertically(tween(420)) { it } + fadeIn(tween(420)),
            exit = slideOutVertically(tween(320)) { it } + fadeOut(tween(320))
        ) {
            PlayerScreen(
                vm = vm,
                onClose = { showPlayer = false },
                onOpenEq = { showEq = true }
            )
        }

        AnimatedVisibility(
            visible = showEq,
            enter = slideInVertically(tween(380)) { it } + fadeIn(tween(380)),
            exit = slideOutVertically(tween(300)) { it } + fadeOut(tween(300))
        ) {
            EqualizerScreen(onClose = { showEq = false })
        }

        AnimatedVisibility(
            visible = showSplash,
            enter = EnterTransition.None,
            exit = fadeOut(tween(500))
        ) {
            SplashScreen(onFinished = { showSplash = false })
        }
    }
}
