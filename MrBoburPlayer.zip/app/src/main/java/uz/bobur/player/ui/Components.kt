package uz.bobur.player.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.bobur.player.R

/** Qorong'u yarim shaffof qatlam bilan 1-rasm (yulduzli osmon) — butun ilova foni. */
@Composable
fun AppBackground(overlayAlpha: Float = 0.58f) {
    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.bg_main),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.Black.copy(alpha = overlayAlpha - 0.10f),
                            Color.Black.copy(alpha = overlayAlpha + 0.20f)
                        )
                    )
                )
        )
    }
}

/** Shisha (glass) effektli kartochka. */
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(20.dp),
    alpha: Float = 0.10f,
    base: Color = Color.Transparent,
): Modifier = this
    .clip(shape)
    .background(base, shape)
    .background(
        Brush.verticalGradient(
            listOf(Color.White.copy(alpha = alpha + 0.05f), Color.White.copy(alpha = (alpha - 0.03f).coerceAtLeast(0f)))
        ),
        shape
    )
    .border(
        1.dp,
        Brush.linearGradient(listOf(Color.White.copy(alpha = 0.35f), Color.White.copy(alpha = 0.05f))),
        shape
    )

/** Bosilganda yengil kichrayadigan tugma effekti. */
@Composable
fun Modifier.pressScale(onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        targetValue = if (pressed) 0.90f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    return this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

@Composable
fun IconBtn(
    kind: Ic,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    iconSize: Dp = 24.dp,
    tint: Color = Color.White,
) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .pressScale(onClick),
        contentAlignment = Alignment.Center
    ) {
        AppIcon(kind, Modifier.size(iconSize), tint)
    }
}

/** Gradient (#FF3B5C -> #7B2FF7) aylana play/pause tugmasi. */
@Composable
fun PlayPauseButton(playing: Boolean, size: Dp, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(size)
            .shadow(14.dp, CircleShape, ambientColor = Pink, spotColor = Purple)
            .clip(CircleShape)
            .background(AccentBrush)
            .pressScale(onClick),
        contentAlignment = Alignment.Center
    ) {
        AppIcon(if (playing) Ic.Pause else Ic.Play, Modifier.size(size * 0.46f), Color.White)
    }
}

@Composable
fun GradientButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(AccentBrush)
            .pressScale(onClick)
            .padding(horizontal = 26.dp, vertical = 13.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Harakatlanuvchi 3 ustunli equalizer chiziqlari. */
@Composable
fun EqBars(playing: Boolean, modifier: Modifier = Modifier.size(20.dp), color: Color = Pink) {
    val t = rememberInfiniteTransition(label = "eqbars")
    val a by t.animateFloat(
        initialValue = 0.25f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(420, easing = LinearEasing), RepeatMode.Reverse),
        label = "a"
    )
    val b by t.animateFloat(
        initialValue = 0.35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(560, easing = LinearEasing), RepeatMode.Reverse),
        label = "b"
    )
    val c by t.animateFloat(
        initialValue = 0.20f, targetValue = 0.95f,
        animationSpec = infiniteRepeatable(tween(340, easing = LinearEasing), RepeatMode.Reverse),
        label = "c"
    )
    Canvas(modifier) {
        val bw = size.width / 5f
        val hs = if (playing) listOf(a, b, c) else listOf(0.30f, 0.30f, 0.30f)
        hs.forEachIndexed { i, f ->
            val bh = size.height * f
            drawRoundRect(
                color = color,
                topLeft = Offset(i * 2 * bw, size.height - bh),
                size = Size(bw, bh),
                cornerRadius = CornerRadius(bw / 2f)
            )
        }
    }
}

/** Ilova logotipi: gradient doira ichida nota. */
@Composable
fun LogoMark(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        drawCircle(
            brush = Brush.linearGradient(
                colors = listOf(Pink, Purple),
                start = Offset(0f, 0f),
                end = Offset(w, w)
            )
        )
        drawOval(Color.White, Offset(w * 0.28f, w * 0.56f), Size(w * 0.24f, w * 0.17f))
        drawRect(Color.White, Offset(w * 0.49f, w * 0.26f), Size(w * 0.045f, w * 0.38f))
        val flag = Path().apply {
            moveTo(w * 0.535f, w * 0.26f)
            cubicTo(w * 0.66f, w * 0.29f, w * 0.73f, w * 0.37f, w * 0.71f, w * 0.50f)
            cubicTo(w * 0.67f, w * 0.42f, w * 0.60f, w * 0.38f, w * 0.535f, w * 0.37f)
            close()
        }
        drawPath(flag, Color.White)
    }
}

@Composable
fun appSliderColors() = SliderDefaults.colors(
    thumbColor = Color.White,
    activeTrackColor = Pink,
    inactiveTrackColor = Color.White.copy(alpha = 0.25f),
    disabledThumbColor = Color.White.copy(alpha = 0.40f),
    disabledActiveTrackColor = Pink.copy(alpha = 0.40f),
    disabledInactiveTrackColor = Color.White.copy(alpha = 0.12f),
)
