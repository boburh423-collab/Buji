package uz.bobur.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import uz.bobur.player.MusicViewModel
import uz.bobur.player.R
import uz.bobur.player.Song
import uz.bobur.player.formatTime

@Composable
fun LibraryScreen(
    vm: MusicViewModel,
    granted: Boolean,
    onRequestPermission: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPlayer: () -> Unit,
) {
    Box(Modifier.fillMaxSize()) {
        AppBackground()

        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Header(count = vm.songs.size)
            SearchBar(vm.query) { vm.query = it }
            Spacer(Modifier.height(8.dp))

            when {
                !granted -> PermissionCard(onRequestPermission, onOpenSettings)

                vm.loading && vm.songs.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    CircularProgressIndicator(color = Pink)
                }

                else -> {
                    val list = remember(vm.songs, vm.query) {
                        val q = vm.query.trim().lowercase()
                        if (q.isEmpty()) vm.songs
                        else vm.songs.filter {
                            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q)
                        }
                    }
                    if (list.isEmpty()) {
                        Box(Modifier.fillMaxSize().padding(32.dp), Alignment.TopCenter) {
                            Text(
                                if (vm.query.isNotBlank()) "Hech narsa topilmadi" else "Qo'shiqlar topilmadi",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 16.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(top = 40.dp)
                            )
                        }
                    } else {
                        LazyColumn(
                            Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(bottom = 140.dp)
                        ) {
                            itemsIndexed(list, key = { _, s -> s.id }) { index, song ->
                                SongRow(
                                    index = index,
                                    song = song,
                                    isCurrent = vm.currentId == song.id.toString(),
                                    isPlaying = vm.isPlaying,
                                    vm = vm,
                                    onClick = { vm.play(list, index) }
                                )
                            }
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = vm.currentId != null,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(tween(350)) { it } + fadeIn(tween(350)),
            exit = slideOutVertically(tween(250)) { it } + fadeOut(tween(250))
        ) {
            MiniPlayer(vm, onOpenPlayer)
        }
    }
}

@Composable
private fun Header(count: Int) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 18.dp, end = 18.dp, top = 14.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LogoMark(Modifier.size(42.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text("Mr.Bobur Player", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("$count ta qo'shiq", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
        }
    }
}

@Composable
private fun SearchBar(query: String, onChange: (String) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
            .glass(RoundedCornerShape(50), 0.12f)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(Ic.Search, Modifier.size(20.dp), Color.White.copy(alpha = 0.7f))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (query.isEmpty()) {
                Text(
                    "Qo'shiq yoki ijrochi qidirish",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 15.sp
                )
            }
            BasicTextField(
                value = query,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                cursorBrush = SolidColor(Pink),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (query.isNotEmpty()) {
            Text(
                "✕",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 16.sp,
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable { onChange("") }
                    .padding(horizontal = 6.dp)
            )
        }
    }
}

@Composable
private fun PermissionCard(onRequest: () -> Unit, onSettings: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(20.dp)
            .glass(RoundedCornerShape(24.dp), 0.12f)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Telefondagi qo'shiqlarni topish uchun musiqa ruxsati kerak.",
            color = Color.White,
            fontSize = 16.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(18.dp))
        GradientButton("Ruxsat berish", onRequest)
        Spacer(Modifier.height(10.dp))
        Text(
            "Sozlamalarni ochish",
            color = Color.White.copy(alpha = 0.75f),
            fontSize = 14.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable(onClick = onSettings)
                .padding(12.dp)
        )
    }
}

@Composable
private fun SongRow(
    index: Int,
    song: Song,
    isCurrent: Boolean,
    isPlaying: Boolean,
    vm: MusicViewModel,
    onClick: () -> Unit,
) {
    // Birin-ketin kirish animatsiyasi (bir marta o'ynaladi).
    val progress = remember { Animatable(if (vm.animatedIds.contains(song.id)) 1f else 0f) }
    LaunchedEffect(song.id) {
        if (progress.value < 1f) {
            delay(if (index < 10) index * 45L else 0L)
            progress.animateTo(1f, tween(420, easing = FastOutSlowInEasing))
            vm.animatedIds.add(song.id)
        }
    }

    Row(
        Modifier
            .fillMaxWidth()
            .graphicsLayer {
                alpha = progress.value
                translationY = (1f - progress.value) * 70f
            }
            .padding(horizontal = 14.dp, vertical = 5.dp)
            .glass(RoundedCornerShape(20.dp), if (isCurrent) 0.17f else 0.09f)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(
                    if (isCurrent) AccentBrush
                    else Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.06f))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            AppIcon(Ic.Note, Modifier.size(22.dp), Color.White)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title,
                color = if (isCurrent) Pink else Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                song.artist,
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        if (isCurrent) {
            EqBars(isPlaying, Modifier.size(20.dp, 18.dp), Pink)
            Spacer(Modifier.width(8.dp))
        }
        Text(
            formatTime(song.durationMs),
            color = Color.White.copy(alpha = 0.6f),
            fontSize = 13.sp
        )
    }
}

@Composable
private fun MiniPlayer(vm: MusicViewModel, onOpen: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .glass(RoundedCornerShape(26.dp), 0.14f, base = Color(0xFF12121C).copy(alpha = 0.82f))
            .clickable(onClick = onOpen)
    ) {
        Row(
            Modifier.padding(start = 10.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(R.drawable.art_circle),
                contentDescription = null,
                modifier = Modifier.size(46.dp).clip(CircleShape),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    vm.currentTitle,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    vm.currentArtist,
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            PlayPauseButton(vm.isPlaying, 44.dp, { vm.togglePlay() })
            Spacer(Modifier.width(4.dp))
            IconBtn(Ic.Next, { vm.next() }, size = 44.dp, iconSize = 22.dp)
        }
        val frac = if (vm.durationMs > 0) (vm.positionMs.toFloat() / vm.durationMs).coerceIn(0f, 1f) else 0f
        Box(
            Modifier
                .fillMaxWidth()
                .height(3.dp)
                .background(Color.White.copy(alpha = 0.12f))
        ) {
            Box(
                Modifier
                    .fillMaxWidth(frac)
                    .fillMaxHeight()
                    .background(AccentBrush)
            )
        }
    }
}
