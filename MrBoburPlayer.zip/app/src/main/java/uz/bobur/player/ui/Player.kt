package uz.bobur.player.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.delay
import uz.bobur.player.MusicViewModel
import uz.bobur.player.R
import uz.bobur.player.formatTime
import kotlin.math.roundToInt

@Composable
fun PlayerScreen(vm: MusicViewModel, onClose: () -> Unit, onOpenEq: () -> Unit) {
    // Ovoz balandligini tizim bilan sinxron saqlaydi (jismoniy tugmalar uchun).
    LaunchedEffect(Unit) {
        while (true) {
            vm.refreshVolume()
            delay(400)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures { } } // orqadagi ro'yxatga bosilmasin
    ) {
        AppBackground(overlayAlpha = 0.50f)

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 18.dp)
        ) {
            // Yuqori panel
            Row(
                Modifier.fillMaxWidth().padding(top = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconBtn(Ic.Chevron, onClose, iconSize = 26.dp)
                Text(
                    "Hozir chalinmoqda",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
                IconBtn(Ic.Tune, onOpenEq)
            }

            Spacer(Modifier.weight(1f))

            ArtWithWaves(playing = vm.isPlaying, modifier = Modifier.align(Alignment.CenterHorizontally))

            Spacer(Modifier.height(10.dp))
            Text(
                vm.currentTitle,
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
            )
            Spacer(Modifier.height(4.dp))
            Text(
                vm.currentArtist,
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
            )

            Spacer(Modifier.weight(1f))

            ControlsCard(vm)
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun ArtWithWaves(playing: Boolean, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "art")
    val breathe by inf.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathe"
    )
    val wave by inf.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing)),
        label = "wave"
    )
    val factor by animateFloatAsState(
        targetValue = if (playing) 1f else 0f,
        animationSpec = tween(500),
        label = "factor"
    )
    val scale = 1f + 0.06f * breathe * factor

    Box(modifier.size(300.dp), contentAlignment = Alignment.Center) {
        // Atrofga tarqaluvchi to'lqin halqalar
        Canvas(Modifier.fillMaxSize()) {
            val base = 105.dp.toPx() * scale
            val maxR = size.minDimension / 2f
            for (i in 0..2) {
                val q = (wave + i / 3f) % 1f
                val r = base + (maxR - base) * q
                drawCircle(
                    color = (if (i % 2 == 0) Pink else Purple).copy(alpha = (1f - q) * 0.55f * factor),
                    radius = r,
                    center = Offset(size.width / 2f, size.height / 2f),
                    style = Stroke(width = 1.dp.toPx() + 3.dp.toPx() * (1f - q))
                )
            }
        }
        Image(
            painter = painterResource(R.drawable.art_circle),
            contentDescription = null,
            modifier = Modifier
                .size(210.dp)
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .shadow(24.dp, CircleShape, ambientColor = Pink, spotColor = Purple)
                .clip(CircleShape)
                .border(3.dp, AccentBrush, CircleShape),
            contentScale = ContentScale.Crop
        )
    }
}

@Composable
private fun ControlsCard(vm: MusicViewModel) {
    val shape = RoundedCornerShape(32.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .border(
                1.dp,
                Brush.linearGradient(listOf(Color.White.copy(alpha = 0.40f), Color.White.copy(alpha = 0.06f))),
                shape
            )
    ) {
        // 2-rasm (qalamda chizilgan ko'z) — tugmalar orqa foni
        Image(
            painter = painterResource(R.drawable.bg_sketch),
            contentDescription = null,
            modifier = Modifier.matchParentSize(),
            contentScale = ContentScale.Crop,
            alignment = BiasAlignment(0f, -0.25f)
        )
        Box(
            Modifier
                .matchParentSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Black.copy(alpha = 0.48f), Color.Black.copy(alpha = 0.74f))
                    )
                )
        )

        Column(Modifier.padding(horizontal = 18.dp, vertical = 16.dp)) {
            // Seek slayder
            var dragging by remember { mutableStateOf(false) }
            var dragValue by remember { mutableFloatStateOf(0f) }
            val dur = vm.durationMs.coerceAtLeast(1L).toFloat()
            val shown = if (dragging) dragValue else vm.positionMs.toFloat()
            Slider(
                value = shown.coerceIn(0f, dur),
                onValueChange = { dragging = true; dragValue = it },
                onValueChangeFinished = {
                    vm.seekTo(dragValue.toLong())
                    dragging = false
                },
                valueRange = 0f..dur,
                colors = appSliderColors()
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(shown.toLong()), color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                Text(formatTime(vm.durationMs), color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
            }

            Spacer(Modifier.height(10.dp))

            // Asosiy tugmalar
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconBtn(
                    Ic.Shuffle, { vm.toggleShuffle() },
                    tint = if (vm.shuffle) Pink else Color.White.copy(alpha = 0.75f)
                )
                IconBtn(Ic.Prev, { vm.previous() }, size = 54.dp, iconSize = 30.dp)
                PlayPauseButton(vm.isPlaying, 78.dp, { vm.togglePlay() })
                IconBtn(Ic.Next, { vm.next() }, size = 54.dp, iconSize = 30.dp)
                Box(contentAlignment = Alignment.Center) {
                    val active = vm.repeatMode != Player.REPEAT_MODE_OFF
                    IconBtn(
                        Ic.Repeat, { vm.cycleRepeat() },
                        tint = if (active) Pink else Color.White.copy(alpha = 0.75f)
                    )
                    if (vm.repeatMode == Player.REPEAT_MODE_ONE) {
                        Text("1", color = Pink, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // Ovoz balandligi (AudioManager)
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(Ic.Volume, Modifier.size(22.dp), Color.White.copy(alpha = 0.85f))
                Spacer(Modifier.width(8.dp))
                Slider(
                    value = vm.volume.toFloat().coerceIn(0f, vm.maxVolume.toFloat()),
                    onValueChange = { vm.setVolume(it.roundToInt()) },
                    valueRange = 0f..vm.maxVolume.toFloat(),
                    colors = appSliderColors(),
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
