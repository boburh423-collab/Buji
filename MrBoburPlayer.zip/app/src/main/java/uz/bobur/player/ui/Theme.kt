package uz.bobur.player.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Pink = Color(0xFFFF3B5C)
val Purple = Color(0xFF7B2FF7)
val AccentBrush = Brush.linearGradient(listOf(Pink, Purple))

@Composable
fun MrBoburTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pink,
            secondary = Purple,
            background = Color(0xFF0B0B14),
            surface = Color(0xFF14141F),
            onBackground = Color.White,
            onSurface = Color.White,
        ),
        content = content
    )
}
