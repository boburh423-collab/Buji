package uz.bobur.player

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Ekvalayzer, bas va 3D (Virtualizer) effektlari.
 * Xizmat (PlaybackService) pleyerning audio sessiyasiga ulaydi, UI esa shu obyektni boshqaradi.
 */
object AudioFx {

    var enabled by mutableStateOf(true)
        private set
    var available by mutableStateOf(false)
        private set
    var minLevel by mutableIntStateOf(-1500)
        private set
    var maxLevel by mutableIntStateOf(1500)
        private set
    val freqs = mutableStateListOf<Int>()
    val levels = mutableStateListOf<Int>()
    var bass by mutableIntStateOf(0)
        private set
    var virt by mutableIntStateOf(0)
        private set
    var bassSupported by mutableStateOf(false)
        private set
    var virtSupported by mutableStateOf(false)
        private set

    private var eq: Equalizer? = null
    private var bb: BassBoost? = null
    private var vz: Virtualizer? = null
    private var prefs: SharedPreferences? = null

    fun attach(context: Context, sessionId: Int) {
        val p = context.applicationContext.getSharedPreferences("audio_fx", Context.MODE_PRIVATE)
        prefs = p
        releaseEffects()
        if (sessionId == 0) return

        enabled = p.getBoolean("enabled", true)
        bass = p.getInt("bass", 0).coerceIn(0, 1000)
        virt = p.getInt("virt", 0).coerceIn(0, 1000)

        try {
            val e = Equalizer(0, sessionId)
            eq = e
            val n = e.numberOfBands.toInt()
            val range = e.bandLevelRange
            minLevel = range[0].toInt()
            maxLevel = range[1].toInt()
            freqs.clear()
            levels.clear()
            for (i in 0 until n) {
                freqs.add(e.getCenterFreq(i.toShort()) / 1000)
                levels.add(p.getInt("band_$i", 0).coerceIn(minLevel, maxLevel))
            }
            available = n > 0
        } catch (t: Throwable) {
            eq = null
            available = false
        }

        try {
            val b = BassBoost(0, sessionId)
            bb = b
            bassSupported = b.strengthSupported
        } catch (t: Throwable) {
            bb = null
            bassSupported = false
        }

        try {
            val v = Virtualizer(0, sessionId)
            vz = v
            virtSupported = v.strengthSupported
        } catch (t: Throwable) {
            vz = null
            virtSupported = false
        }

        applyAll()
    }

    private fun applyAll() {
        try {
            eq?.let { e ->
                levels.forEachIndexed { i, l -> e.setBandLevel(i.toShort(), l.toShort()) }
                e.setEnabled(enabled)
            }
        } catch (_: Throwable) {
        }
        try {
            bb?.let { b ->
                if (b.strengthSupported) b.setStrength(bass.toShort())
                b.setEnabled(enabled)
            }
        } catch (_: Throwable) {
        }
        try {
            vz?.let { v ->
                if (v.strengthSupported) v.setStrength(virt.toShort())
                v.setEnabled(enabled)
            }
        } catch (_: Throwable) {
        }
    }

    fun setEnabled(value: Boolean) {
        enabled = value
        prefs?.edit()?.putBoolean("enabled", value)?.apply()
        applyAll()
    }

    fun setBand(index: Int, level: Int) {
        if (index !in levels.indices) return
        val v = level.coerceIn(minLevel, maxLevel)
        levels[index] = v
        prefs?.edit()?.putInt("band_$index", v)?.apply()
        try {
            eq?.setBandLevel(index.toShort(), v.toShort())
        } catch (_: Throwable) {
        }
    }

    fun setBass(value: Int) {
        bass = value.coerceIn(0, 1000)
        prefs?.edit()?.putInt("bass", bass)?.apply()
        try {
            bb?.let { if (it.strengthSupported) it.setStrength(bass.toShort()) }
        } catch (_: Throwable) {
        }
    }

    fun setVirt(value: Int) {
        virt = value.coerceIn(0, 1000)
        prefs?.edit()?.putInt("virt", virt)?.apply()
        try {
            vz?.let { if (it.strengthSupported) it.setStrength(virt.toShort()) }
        } catch (_: Throwable) {
        }
    }

    /** "Tiklash" tugmasi: hamma narsa boshlang'ich holatga qaytadi. */
    fun reset() {
        for (i in levels.indices) setBand(i, 0)
        setBass(0)
        setVirt(0)
    }

    private fun releaseEffects() {
        try { eq?.release() } catch (_: Throwable) {}
        try { bb?.release() } catch (_: Throwable) {}
        try { vz?.release() } catch (_: Throwable) {}
        eq = null
        bb = null
        vz = null
        available = false
    }

    fun release() = releaseEffects()
}
