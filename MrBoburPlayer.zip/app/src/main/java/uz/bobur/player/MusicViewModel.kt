package uz.bobur.player

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MusicViewModel(app: Application) : AndroidViewModel(app) {

    var songs by mutableStateOf<List<Song>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var query by mutableStateOf("")

    var isPlaying by mutableStateOf(false)
        private set
    var currentId by mutableStateOf<String?>(null)
        private set
    var currentTitle by mutableStateOf("")
        private set
    var currentArtist by mutableStateOf("")
        private set
    var positionMs by mutableLongStateOf(0L)
        private set
    var durationMs by mutableLongStateOf(0L)
        private set
    var shuffle by mutableStateOf(false)
        private set
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF)
        private set
    var volume by mutableIntStateOf(0)
        private set
    var maxVolume by mutableIntStateOf(1)
        private set

    /** Ro'yxatda kirish animatsiyasi o'ynalgan qo'shiqlar (qayta o'ynamaslik uchun). */
    val animatedIds = HashSet<Long>()

    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var queueIds: List<String> = emptyList()

    private val audioManager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val artworkUri: Uri =
        Uri.parse("android.resource://${app.packageName}/drawable/art_circle")

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) = updatePlaying()
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = updatePlaying()
        override fun onPlaybackStateChanged(playbackState: Int) {
            updatePlaying()
            syncCurrent()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = syncCurrent()
        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            shuffle = shuffleModeEnabled
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            this@MusicViewModel.repeatMode = repeatMode
        }
    }

    init {
        refreshVolume()
        // Vaqt chizig'i uchun joriy pozitsiyani muntazam yangilab turadi.
        viewModelScope.launch {
            while (true) {
                controller?.let { c ->
                    positionMs = c.currentPosition.coerceAtLeast(0L)
                    val d = c.duration
                    durationMs = if (d > 0L) d else 0L
                }
                delay(250)
            }
        }
    }

    fun connect() {
        if (controllerFuture != null) return
        val app = getApplication<Application>()
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                shuffle = c.shuffleModeEnabled
                repeatMode = c.repeatMode
                queueIds = (0 until c.mediaItemCount).map { c.getMediaItemAt(it).mediaId }
                updatePlaying()
                syncCurrent()
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(app))
    }

    private fun updatePlaying() {
        val c = controller
        isPlaying = c != null && c.playWhenReady &&
            c.playbackState != Player.STATE_ENDED && c.playbackState != Player.STATE_IDLE
    }

    private fun syncCurrent() {
        val item = controller?.currentMediaItem
        currentId = item?.mediaId?.takeIf { it.isNotEmpty() }
        currentTitle = item?.mediaMetadata?.title?.toString() ?: ""
        currentArtist = item?.mediaMetadata?.artist?.toString() ?: ""
    }

    fun loadSongs() {
        if (loading) return
        loading = true
        val app = getApplication<Application>()
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    SongRepository.load(app)
                } catch (_: Exception) {
                    emptyList()
                }
            }
            songs = result
            loading = false
        }
    }

    fun play(list: List<Song>, index: Int) {
        val c = controller ?: return
        if (index !in list.indices) return
        val ids = list.map { it.id.toString() }
        if (ids == queueIds && c.mediaItemCount == ids.size) {
            c.seekTo(index, 0L)
        } else {
            c.setMediaItems(list.map { it.toMediaItem(artworkUri) }, index, 0L)
            queueIds = ids
        }
        c.prepare()
        c.play()
    }

    fun togglePlay() {
        val c = controller ?: return
        if (isPlaying) {
            c.pause()
        } else {
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(0L)
            c.play()
        }
    }

    fun next() {
        val c = controller ?: return
        if (c.hasNextMediaItem()) c.seekToNextMediaItem()
        else if (c.mediaItemCount > 0) c.seekTo(0, 0L)
    }

    fun previous() {
        controller?.seekToPrevious()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        positionMs = ms
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    /** O'chiq -> hammasi -> bitta -> o'chiq */
    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun refreshVolume() {
        maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        volume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
    }

    fun setVolume(value: Int) {
        val v = value.coerceIn(0, maxVolume)
        try {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
        } catch (_: SecurityException) {
        }
        volume = v
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        controllerFuture = null
        super.onCleared()
    }
}
