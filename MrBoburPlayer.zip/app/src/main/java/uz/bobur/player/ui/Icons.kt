package uz.bobur.player.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

/** Barcha ikonlar Canvas bilan chizilgan, qo'shimcha kutubxona kerak emas. */
enum class Ic { Play, Pause, Next, Prev, Shuffle, Repeat, Search, Chevron, Tune, Volume, Note }

@Composable
fun AppIcon(kind: Ic, modifier: Modifier = Modifier, tint: Color = Color.White) {
    Canvas(modifier) { drawIcon(kind, tint) }
}

private fun DrawScope.drawIcon(kind: Ic, c: Color) {
    val w = size.width
    val h = size.height
    val sw = w * 0.09f
    val line = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun p(x: Float, y: Float) = Offset(x * w, y * h)

    when (kind) {
        Ic.Play -> {
            val path = Path().apply {
                moveTo(w * 0.30f, h * 0.18f)
                lineTo(w * 0.30f, h * 0.82f)
                lineTo(w * 0.82f, h * 0.50f)
                close()
            }
            drawPath(path, c)
            drawPath(path, c, style = Stroke(width = w * 0.08f, join = StrokeJoin.Round))
        }

        Ic.Pause -> {
            drawRoundRect(c, p(0.26f, 0.18f), Size(w * 0.18f, h * 0.64f), CornerRadius(w * 0.05f))
            drawRoundRect(c, p(0.56f, 0.18f), Size(w * 0.18f, h * 0.64f), CornerRadius(w * 0.05f))
        }

        Ic.Next -> {
            val path = Path().apply {
                moveTo(w * 0.20f, h * 0.20f)
                lineTo(w * 0.20f, h * 0.80f)
                lineTo(w * 0.66f, h * 0.50f)
                close()
            }
            drawPath(path, c)
            drawRoundRect(c, p(0.72f, 0.20f), Size(w * 0.10f, h * 0.60f), CornerRadius(w * 0.03f))
        }

        Ic.Prev -> {
            val path = Path().apply {
                moveTo(w * 0.80f, h * 0.20f)
                lineTo(w * 0.80f, h * 0.80f)
                lineTo(w * 0.34f, h * 0.50f)
                close()
            }
            drawPath(path, c)
            drawRoundRect(c, p(0.18f, 0.20f), Size(w * 0.10f, h * 0.60f), CornerRadius(w * 0.03f))
        }

        Ic.Shuffle -> {
            val a = Path().apply {
                moveTo(w * 0.10f, h * 0.30f)
                lineTo(w * 0.34f, h * 0.30f)
                lineTo(w * 0.58f, h * 0.70f)
                lineTo(w * 0.74f, h * 0.70f)
            }
            val b = Path().apply {
                moveTo(w * 0.10f, h * 0.70f)
                lineTo(w * 0.34f, h * 0.70f)
                lineTo(w * 0.58f, h * 0.30f)
                lineTo(w * 0.74f, h * 0.30f)
            }
            drawPath(a, c, style = line)
            drawPath(b, c, style = line)
            fun head(y: Float) {
                val t = Path().apply {
                    moveTo(w * 0.72f, h * (y - 0.12f))
                    lineTo(w * 0.92f, h * y)
                    lineTo(w * 0.72f, h * (y + 0.12f))
                    close()
                }
                drawPath(t, c)
            }
            head(0.70f)
            head(0.30f)
        }

        Ic.Repeat -> {
            val top = Path().apply {
                moveTo(w * 0.18f, h * 0.58f)
                lineTo(w * 0.18f, h * 0.42f)
                lineTo(w * 0.28f, h * 0.32f)
                lineTo(w * 0.68f, h * 0.32f)
            }
            val bottom = Path().apply {
                moveTo(w * 0.82f, h * 0.42f)
                lineTo(w * 0.82f, h * 0.58f)
                lineTo(w * 0.72f, h * 0.68f)
                lineTo(w * 0.32f, h * 0.68f)
            }
            drawPath(top, c, style = line)
            drawPath(bottom, c, style = line)
            val right = Path().apply {
                moveTo(w * 0.66f, h * 0.18f)
                lineTo(w * 0.88f, h * 0.32f)
                lineTo(w * 0.66f, h * 0.46f)
                close()
            }
            val left = Path().apply {
                moveTo(w * 0.34f, h * 0.54f)
                lineTo(w * 0.12f, h * 0.68f)
                lineTo(w * 0.34f, h * 0.82f)
                close()
            }
            drawPath(right, c)
            drawPath(left, c)
        }

        Ic.Search -> {
            drawCircle(c, radius = w * 0.27f, center = p(0.43f, 0.43f), style = line)
            drawLine(c, p(0.63f, 0.63f), p(0.86f, 0.86f), strokeWidth = sw, cap = StrokeCap.Round)
        }

        Ic.Chevron -> {
            val path = Path().apply {
                moveTo(w * 0.20f, h * 0.35f)
                lineTo(w * 0.50f, h * 0.65f)
                lineTo(w * 0.80f, h * 0.35f)
            }
            drawPath(path, c, style = line)
        }

        Ic.Tune -> {
            val xs = floatArrayOf(0.25f, 0.5f, 0.75f)
            val ys = floatArrayOf(0.66f, 0.34f, 0.56f)
            for (i in xs.indices) {
                drawLine(c, p(xs[i], 0.15f), p(xs[i], 0.85f), strokeWidth = sw, cap = StrokeCap.Round)
                drawCircle(c, radius = w * 0.11f, center = p(xs[i], ys[i]))
            }
        }

        Ic.Volume -> {
            val body = Path().apply {
                moveTo(w * 0.10f, h * 0.38f)
                lineTo(w * 0.28f, h * 0.38f)
                lineTo(w * 0.48f, h * 0.20f)
                lineTo(w * 0.48f, h * 0.80f)
                lineTo(w * 0.28f, h * 0.62f)
                lineTo(w * 0.10f, h * 0.62f)
                close()
            }
            drawPath(body, c)
            drawArc(
                c, startAngle = -50f, sweepAngle = 100f, useCenter = false,
                topLeft = p(0.32f, 0.32f), size = Size(w * 0.36f, h * 0.36f), style = line
            )
            drawArc(
                c, startAngle = -50f, sweepAngle = 100f, useCenter = false,
                topLeft = p(0.18f, 0.18f), size = Size(w * 0.64f, h * 0.64f), style = line
            )
        }

        Ic.Note -> {
            drawOval(c, p(0.18f, 0.62f), Size(w * 0.34f, h * 0.24f))
            drawRect(c, p(0.46f, 0.16f), Size(w * 0.07f, h * 0.58f))
            val flag = Path().apply {
                moveTo(w * 0.53f, h * 0.16f)
                cubicTo(w * 0.72f, h * 0.20f, w * 0.84f, h * 0.34f, w * 0.80f, h * 0.52f)
                cubicTo(w * 0.74f, h * 0.40f, w * 0.64f, h * 0.34f, w * 0.53f, h * 0.32f)
                close()
            }
            drawPath(flag, c)
        }
    }
}
