# Mr.Bobur Player — APK yasash yo'riqnomasi

Internet kerak emas, reklama yo'q. Ilova faqat telefondagi musiqani chaladi.

## 1-usul: GitHub Actions (eng oson, Android Studio shart emas)

1. https://github.com saytida bepul akkaunt oching va **New repository** bosing (nomi: `MrBoburPlayer`).
2. Shu ZIP ichidagi **hamma narsani** (`.github` papkasi bilan, u yashirin papka) repozitoriyga yuklang:
   - Kompyuterda: repozitoriy sahifasida **Add file → Upload files**, papka ichidagi hamma fayl va papkalarni sudrab tashlang.
   - Yoki terminalda:
     ```
     git init
     git add .
     git commit -m "Mr.Bobur Player"
     git branch -M main
     git remote add origin https://github.com/<login>/MrBoburPlayer.git
     git push -u origin main
     ```
3. Repozitoriyda **Actions** bo'limiga kiring. **APK yasash** ishi o'zi boshlanadi (3–6 daqiqa). Boshlanmasa, uni tanlab **Run workflow** bosing.
4. Ish yashil bo'lgach, ichiga kirib pastdagi **Artifacts → MrBoburPlayer-apk** ni yuklab oling. Ichida `app-debug.apk` bor.
5. APK ni telefonga o'tkazing va o'rnating (kerak bo'lsa "Noma'lum manbalardan o'rnatish" ni yoqing).

## 2-usul: Android Studio

1. Android Studio (Ladybug yoki yangiroq) ni oching → **Open** → shu papkani tanlang.
2. Gradle sinxronlanishini kuting (internet kerak, faqat yig'ish paytida).
3. **Build → Build APK(s)**. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## 3-usul: buyruq qatori

Java 17, Android SDK va Gradle 8.9 o'rnatilgan bo'lsa:

```
gradle assembleDebug
```

## Ilova qanday ishlaydi

- Birinchi ochilganda musiqa va bildirishnoma ruxsatini so'raydi.
- Qo'shiqlar MediaStore orqali topiladi (30 soniyadan qisqalari olinmaydi).
- Mini-pleyerga bosing, pleyer ekrani pastdan chiqadi. Yuqori o'ngdagi tugma ekvalayzerni ochadi.
- Fon: 1-rasm (yulduzli osmon). Pleyer tugmalari paneli: 2-rasm (qalamda chizilgan ko'z).
  Rasmlar `app/src/main/res/drawable-nodpi/` ichida: `bg_main.jpg`, `bg_sketch.jpg`, `art_circle.jpg`.
  Almashtirmoqchi bo'lsangiz, shu nomdagi fayllarni almashtiring.
